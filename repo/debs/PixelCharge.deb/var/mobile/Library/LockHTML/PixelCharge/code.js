function init() {
    updateWidget();
    setInterval("updateWidget();", 1000);
}

function updateWidget() {
    if (batteryCharging) {
        document.getElementById("charge").innerHTML = "Charging Rapidly...";
    }
}