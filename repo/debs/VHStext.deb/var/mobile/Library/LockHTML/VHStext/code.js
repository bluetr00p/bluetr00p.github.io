function init() {
    updateWidget();
    setInterval("updateWidget();", 1000);
}

function updateWidget() {
    var currentTime = new Date();
    var currentHours = currentTime.getHours();
    var currentMinutes = currentTime.getMinutes();
    var currnetDate = currentTime.getDate();
    var currentMonth = currentTime.getMonth();
    var currentYear = currentTime.getFullYear();
    
    if (currentMonth == 0) {var currentMonthSTR = "January";}
    if (currentMonth == 1) {var currentMonthSTR = "February";}
    if (currentMonth == 2) {var currentMonthSTR = "March";}
    if (currentMonth == 3) {var currentMonthSTR = "April";}
    if (currentMonth == 4) {var currentMonthSTR = "May";}
    if (currentMonth == 5) {var currentMonthSTR = "June";}
    if (currentMonth == 6) {var currentMonthSTR = "July";}
    if (currentMonth == 7) {var currentMonthSTR = "August";}
    if (currentMonth == 8) {var currentMonthSTR = "September";}
    if (currentMonth == 9) {var currentMonthSTR = "October";}
    if (currentMonth == 10) {var currentMonthSTR = "November";}
    if (currentMonth == 11) {var currentMonthSTR = "December";}
    
    if (currentHours > 12) {
        if (Clock == "12h") {
            currentHours = currentHours - 12;
            if (currentHours <= 0) {document.getElementById("ampm").innerHTML = "AM"}
            if (currentHours >= 11) {document.getElementById("ampm").innerHTML = "PM"}
        }
        if (Clock == "24h") {
            document.getElementById("ampm").innerHTML = "";
        }
    }
    
    
    if (currentHours <= 9) {/*var currentHours = "0" + currentHours;*/}
    if (currentMinutes <= 9) {var currentMinutesSTR = "0" + currentMinutes;} else {
        var currentMinutesSTR = currentMinutes;
    }
    
    document.getElementById("h").innerHTML = currentHours;
    document.getElementById("m").innerHTML = currentMinutesSTR;
    document.getElementById("day").innerHTML = currnetDate;
    document.getElementById("month").innerHTML = currentMonthSTR;
    document.getElementById("year").innerHTML = currentYear;
    console.log(currentTime);
}